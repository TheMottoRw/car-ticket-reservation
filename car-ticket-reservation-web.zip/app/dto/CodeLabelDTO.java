package dto;

public class CodeLabelDTO {
    public String code;
    public String label;

    public CodeLabelDTO(){

    }
    public CodeLabelDTO(String code, String label) {
        this.code = code;
        this.label = label;
    }
}